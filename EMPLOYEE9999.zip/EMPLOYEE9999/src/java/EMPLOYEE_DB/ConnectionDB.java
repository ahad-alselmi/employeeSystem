/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EMPLOYEE_DB;
import exceptions.ESException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLDataException;
import java.sql.SQLException;
import java.util.EmptyStackException;

/**
 *
 * @author Lenovo
 */public class ConnectionDB {

    /**
     *
     * @return
     * @throws exceptions.ESException
     * @throws SQLDataException
     */
    public static Connection getSVCConneciton() throws ESException, SQLDataException {
        Connection conn = null;
        try {
            Class.forName("oracle.jdbc.OracleDriver");
            conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "training", "admin123");
             
            return conn;
        } catch (ClassNotFoundException | SQLException e) {
            throw new SQLDataException(e);
        }
    }

}
/**
 *
 * @author Lenovo
 */

    

