package entites;

import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import javax.faces.bean.ManagedBean;

/**
 *
 * @author Lenovo
 */
@ManagedBean
public class EmployeeEntity implements Serializable {

    int empId;
    String empName;
    String empEmail;

    public EmployeeEntity() {
    }

    public EmployeeEntity(int empId, String empName, String empEmail) {

        this.empId = empId;
        this.empName = empName;
        this.empEmail = empEmail;

    }

    public int getEmpId() {
        return empId;
    }

    public void setEmpId(int empId) {
        this.empId = empId;
    }

    public String getEmpName() {
        return empName;
    }

    public void setEmpName(String empName) {
        this.empName = empName;
    }

    public String getEmpEmail() {
        return empEmail;
    }

    public void setEmpEmail(String empEmail) {
        this.empEmail = empEmail;
    }
/*public static boolean passwordIsDigits(String password){
  for(int i=0;i<password.length();i++){
    if(!character.isDigit(password.charAt(i))){
      return false;
    }
  }
  else return true;
}*/

}
