/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package provider;// this fill should only have  methods  connect to database

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import entites.EmployeeEntity;
import java.sql.PreparedStatement;
import static java.util.Collections.list;
import java.util.Iterator;
import java.util.Scanner;
import javax.enterprise.context.SessionScoped;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.context.FacesContext;

/**
 *
 * @author Lenovo
 */
//@SessionScoped
@ManagedBean
public class EmpolyeeProvider {
     EmpolyeeProvider(){
   
     retEmployees();
     }

    public void addemp(EmployeeEntity emp) throws ClassNotFoundException, SQLException {
        Class.forName("oracle.jdbc.OracleDriver");
        Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "training", "admin123");

        Statement stmt = connection.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);

        // System.out.println("\n &&&&&&&&&&&&&&&&&" + "insert into REGISTRATION_FORM (NAME,EMAIL,GENDER,CENTER,DATEOFBREATH,LEVELS,PREFRENCES)"
        //  + " values ('"+name+"','"+email+"','"+gender+"', '"+center+"', '"+dateofbreath+"', '"+level+"', '"+pref+"')");
        stmt.execute("insert into EMPLOYEE (EMPID,EMPNAME,EMPEMAIL)"
                + " values('" + emp.getEmpId() + "','" + emp.getEmpName() + "','" + emp.getEmpEmail() + "')");

        stmt.close();
        connection.close();

    }

    public List<EmployeeEntity> retEmployees() {
        String QUERY = "Select * from employee";

          List<EmployeeEntity> employees = new ArrayList<>();
        try {
            Class.forName("oracle.jdbc.OracleDriver");
            Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "training", "admin123");
            Statement stmt = connection.createStatement();
            ResultSet rs = stmt.executeQuery(QUERY);

            while (rs.next()) {
                /*int id = rs.getInt("EMPID");
                String name = rs.getString("EMPNAME");
                String email = rs.getString("EMPEMAIL");*/
                EmployeeEntity employee = new EmployeeEntity();
                employee.setEmpId(rs.getInt("EMPID"));
                employee.setEmpName(rs.getString("EMPNAME"));
                employee.setEmpEmail(rs.getString("EMPEMAIL"));
                employees.add(employee);
            }
            return employees;
        } catch (SQLException | ClassNotFoundException ex) {
            ex.printStackTrace();
        }
        return employees;
    }
     
    
    public void UpdateEmployee(EmployeeEntity  emp)throws SQLException{
    /* System.out.println("Enter Employee ID");
     Scanner scan=new Scanner(System.in);
     id=scan.nextInt();
     System.out.println(id);
     EmployeeEntity  emp =new EmployeeEntity ();*/
     String QUERY = "update EMPLOYEE set EMPNAME=?,EMPEMAIL=?  where EMPID=?";
     

     try {
           Class.forName("oracle.jdbc.OracleDriver");
           Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "training", "admin123"); 
           PreparedStatement stmt = connection.prepareStatement(QUERY);
            stmt.setString(1,emp.getEmpName());
            stmt.setString(2,emp.getEmpEmail());
            stmt.setInt(3,emp.getEmpId());
            stmt.executeUpdate() ;
     }
           
      
    catch (SQLException | ClassNotFoundException ex) {
            ex.printStackTrace();
        }
     }//if*/
      public void deleteEmp(EmployeeEntity emp){
          
          String Query= "DELETE  FROM EMPLOYEE where EMPID=?";
          try {
           Class.forName("oracle.jdbc.OracleDriver");
           Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "training", "admin123"); 
           PreparedStatement stmt = connection.prepareStatement(Query);
            //stmt.setString(1,emp.getEmpName());
           // stmt.setString(2,emp.getEmpEmail());
            stmt.setInt(1,emp.getEmpId());
            stmt.executeUpdate() ;
     }
           
      
    catch (SQLException | ClassNotFoundException ex) {
            ex.printStackTrace();
        }
     }//if*/
      
      
 
    /* public EmployeeEntity searchEmp(int id){
     String Query= "SELECT  *FROM EMPLOYEE where EMPID=?";
     
    EmployeeEntity emp=new EmployeeEntity();
    try {
            Class.forName("oracle.jdbc.OracleDriver");
            Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "training", "admin123");
            PreparedStatement stmt = connection.prepareStatement(Query);
            stmt.setInt(1,id);
            ResultSet rs = stmt.executeQuery();
            if(rs.next()){
               /* emp.setEmpId(rs.getInt("EMPID"));
                emp.setEmpName(rs.getString("EMPNAME"));
                emp.setEmpEmail(rs.getString("EMPEMAIL")); */
              /*  System.out.printf("----------",rs.getString(1),rs.getString(2),rs.getString(3));         
            return emp;
                
            }
            
        } catch (SQLException | ClassNotFoundException ex) { 
        }
        return emp;  
    }*/
     
     
     /* public EmployeeEntity retOneEmployee(){
     String Query= "SELECT  EMPNAME, EMPEMAIL FROM EMPLOYEE ?";
     
    EmployeeEntity emp=new EmployeeEntity();
    try {
            Class.forName("oracle.jdbc.OracleDriver");
            Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "training", "admin123");
            Statement stmt = connection.createStatement();
            ResultSet rs = stmt.executeQuery(Query);
            // stmt.setInt(1,emp.getEmpId());
                emp.setEmpId(rs.getInt("EMPID"));
                emp.setEmpName(rs.getString("EMPNAME"));
                emp.setEmpEmail(rs.getString("EMPEMAIL"));          
            return emp;
          
            
        } catch (SQLException | ClassNotFoundException ex) { 
        }
        return emp;
    }*/
      
      
       public EmployeeEntity retOneEmployee(){
     String Query= "SELECT  EMPNAME, EMPEMAIL FROM EMPLOYEE  WHERE EMPID=?";
     EmployeeEntity emp=new EmployeeEntity();
         
    try {
            Class.forName("oracle.jdbc.OracleDriver");
            Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "training", "admin123");
            PreparedStatement stmt = connection.prepareStatement(Query);
            stmt.setInt(1,emp.getEmpId()); 
            ResultSet rs = stmt.executeQuery(Query);
            
           
                emp.setEmpId(rs.getInt("EMPID"));
                emp.setEmpName(rs.getString("EMPNAME"));
                emp.setEmpEmail(rs.getString("EMPEMAIL"));
               
            
                
           rs.close();
           stmt.close();
            
            
        }catch (SQLException | ClassNotFoundException ex) { 
        }
      System.out.println(emp.getEmpName());
        return emp;
    }
       
       public static void validation2() throws ClassNotFoundException {
       
       EmployeeEntity emp= new EmployeeEntity();
        EmployeeEntity tempEmp = new EmployeeEntity();
       Connection connection = null;
      Statement statement = null;
       ResultSet resultSet = null;
 String Query = "SELECT  * FROM EMPLOYEE WHERE id = ? ";
    try {
         Class.forName("oracle.jdbc.OracleDriver");
            
         connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "training", "admin123");
         PreparedStatement stmt = connection.prepareStatement(Query);
            ResultSet rs = stmt.executeQuery(Query);  
        while(rs.next()){
        System.out.print(emp.getEmpId());
        if(emp.getEmpId()== tempEmp.getEmpId() ){
        System.out.print("user is already Exsist");
        
        }
        
        }//then if
    } catch (SQLException e) {
        e.printStackTrace();
        // Handle the exception appropriately
    }
       
       
       }
       /*public void validateId() {
        // Perform the validation logic here
        EmployeeEntity emp= new EmployeeEntity();
        boolean idExists = checkIfIdExists(emp.getEmpId());

        if (idExists) {
            FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_ERROR, "ID already exists", "Please enter a different ID");
            FacesContext.getCurrentInstance().addMessage(null, message);
        } else {
            FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, "ID is available", "You can proceed");
            FacesContext.getCurrentInstance().addMessage(null, message);
        }
    }
     private boolean checkIfIdExists(int id) {
    Connection connection = null;
    PreparedStatement statement = null;
    ResultSet resultSet = null;

    try {
        // Establish a database connection
        connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "training", "admin123");

        // Prepare the SQL statement
        String sql = "SELECT COUNT(*) FROM EMPLOYEE WHERE id = ? ";
        statement = connection.prepareStatement(sql);
        statement.setInt(1, id);

        // Execute the query
        resultSet = statement.executeQuery();

        // Check if the ID exists
        if (resultSet.next()) {
            int count = resultSet.getInt(1);
            return count > 0;
        }
    } catch (SQLException e) {
        e.printStackTrace();
        // Handle the exception appropriately
    } finally {
        // Close the database resources
        try {
            if (resultSet != null) {
                resultSet.close();
            }
            if (statement != null) {
                statement.close();
            }
            if (connection != null) {
                connection.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle the exception appropriately
        }
    }

    return false; // ID doesn't exist or an error occurred   
     }  */
       
        static public void validation (){
       
       int id =12345;
       Scanner s =new Scanner(System.in);
      
      System.out.println("ENTER USER NUMBER");
      int num = s.nextInt();
       if(num==id){
        System.out.println("user is already Exsist");
       
       }
       else 
           System.out.println("user ID not found");
       
       
       
       
       
       }
      /* public static void main(String[] args) {
       
       validation();
       
       }*/
}//class
    
    
    
    
    
        
     
     


