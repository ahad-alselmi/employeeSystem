/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;

//import java.sql.ResultSet;
//import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.faces.bean.ManagedBean;
import provider.EmpolyeeProvider;
import entites.EmployeeEntity;
import exceptions.ESException;
import java.io.PrintStream;
import java.sql.SQLException;
import static java.util.Arrays.stream;
import java.util.ListIterator;
import java.util.Scanner;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.swing.JOptionPane;
import javax.validation.constraints.Max;

/**
 *
 * @author Lenovo
 */
/*@Named(value = "empController")
@SessionScoped
@ManagedBean
public class EmpController implements Serializable {

    private EmpolyeeProvider provider;
    List<EmployeeEntity> employees;
    EmployeeEntity emp;

    public List<EmployeeEntity> getEmployees() {
        return employees;
    }

    public void setEmployees(List<EmployeeEntity> employees) {
        this.employees = employees;
    }

    public EmpController() throws Exception {
        provider = new EmpolyeeProvider();
        employees = new ArrayList<>();
        emp = new EmployeeEntity();

        returnEmployees();
        // returnEmployee() ;
        //UpdateEmp(emp);
//       NewUpdate();

    }

    public void returnEmployees() throws Exception {
        employees = provider.retEmployees();
    }

    public void returnEmployee() throws Exception {
        //emp = provider.retOneEmployee();
        //System.out.println(emp);
        PrintStream stream = new PrintStream(System.out);

        stream.print(emp);
    }

    public EmployeeEntity getEmp() {
        return emp;
    }

    public void setEmp(EmployeeEntity emp) {
        this.emp = emp;
    }

    public void Addemp() throws Exception {
        //validate(emp.getEmpId());
        ListIterator<EmployeeEntity> li = employees.listIterator();
      EmployeeEntity tempEmp = new EmployeeEntity();
      int id=emp.getEmpId();
       while (li.hasNext()) {
            tempEmp = li.next();// to sort new employee
            if (id == tempEmp.getEmpId()) { 
        // provider.validation();}
       }
        provider.addemp(emp);
        returnEmployees();
        }
        
        
    
    /*public void validate() throws Exception {
      
      
        if(emp.getEmpName().length()<=5){  
        System.out.print ("The Name is not long enough");
         }
       
        else{ String s= Integer.toString(emp.getEmpId());//casting
        try {
         int d = Integer.parseInt(s);
         System.out.print ("value is an Integer");
        } catch (NumberFormatException e) {
         System.out.print ("value is NOT an Integer");
        }
        }
    }*/
    
   /*public void validate(int id) throws Exception {
      
      ListIterator<EmployeeEntity> li = employees.listIterator();
      EmployeeEntity tempEmp = new EmployeeEntity();
      id=emp.getEmpId();
       while (li.hasNext()) {
            tempEmp = li.next();// to sort new employee
            if (id == tempEmp.getEmpId()) { 
         FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(+emp.getEmpId() +"is already Exist "  ));
        }
            
       }
    }*/
    
    
    
    /* public void UpdateEmp(EmployeeEntity emp) throws Exception {
          emp= provider.retOneEmployee();
          emp.setEmpId(5000);
          emp.setEmpName("Ali");
          emp.setEmpEmail("sss");
          //System.out.println(arg);
          provider. UpdateEmployee(emp);
          System.out.println(emp);
        
        
        

    }*/

 /*public void updateEmp(EmployeeEntity emp) throws ESException, SQLException {
           //emp=provider.retOneEmployee(emp.getEmpId());  
          for (EmployeeEntity e : employees) {
              if(emp.getEmpId() == e.getEmpId()) {
                  provider.UpdateEmployee(emp);
                  
              }
          }
          
      }
    
   /* public void updateEmp() throws ESException, SQLException {
    int id =0;
    provider.UpdateEmployee(id);
    
    }*/
    /*private void addErrorMessage(Exception ex) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

   /* public void NewUpdate() throws SQLException {
        System.out.println("HERE===");

//        Scanner s = new Scanner(System.in);
//        Scanner s1 = new Scanner(System.in);
        ListIterator<EmployeeEntity> li = employees.listIterator();
        boolean found = false;
//        System.out.println("Enter Employee Number:");
        int empNumber = 7070;
        System.out.println("-----------------------------------------");
        while (li.hasNext()) {
            emp = li.next();
            //System.out.println(emp.getEmpName());
            if (emp.getEmpId() == empNumber) {
                String Name = "fahad";
                String Email = "fahad@fahad.com";
                emp.setEmpEmail(Email);
                emp.setEmpName(Name);
                li.set(emp);
                found = true;
                provider.UpdateEmployee(emp);
            }
        }
        if (!found) {
            System.out.println("Record Not Found");
        } else {
            System.out.println("Record Found");
        }

    }

    public void NewUpdate2() throws SQLException, Exception {
        System.out.println("HERE===");
//        Scanner s = new Scanner(System.in);
//        Scanner s1 = new Scanner(System.in);
        ListIterator<EmployeeEntity> li = employees.listIterator();
        boolean found = false;
//        System.out.println("Enter Employee Number:");
        EmployeeEntity tempEmp = new EmployeeEntity();
        System.out.println("-----------------------------------------");
        while (li.hasNext()) {
            tempEmp = li.next();// to sort new employee
            //System.out.println(emp.getEmpName());
            if (emp.getEmpId() == tempEmp.getEmpId()) {
                  //String Name = "fahad";
                // String Email = "fahad@fahad.com";
                emp.setEmpName(emp.getEmpName());
                emp.setEmpEmail(emp.getEmpEmail());
                li.set(emp);
                found = true;
                provider.UpdateEmployee(emp);
            }
        }
        if (!found) {
            System.out.println("Record Not Found");
        } else {
            System.out.println("Record Found");
        }
       // employees.clear();
       // returnEmployees();//to retraive all employee again  
    }
    
    public void deleteEmp() throws Exception{
    
    System.out.println("DELETE FUNCTION----------------");
    ListIterator<EmployeeEntity> li = employees.listIterator();
     EmployeeEntity tempEmp = new EmployeeEntity();
   while (li.hasNext()){
       tempEmp =li.next();
        if(emp.getEmpId()== tempEmp.getEmpId()){
        //li.remove();
        provider.deleteEmp(emp);
        }
       returnEmployees();
   }
    }*/
    
   /* public void SearchEmployee() throws Exception{
    
    System.out.println("SEARCH FUNCTION----------------");
    ListIterator<EmployeeEntity> li = employees.listIterator();
    EmployeeEntity tempEmp = new EmployeeEntity();
     // int id=tempEmp.getEmpId();
   while (li.hasNext()){
     tempEmp =li.next();
        if(emp.getEmpId()==tempEmp.getEmpId() ){
         provider.retOneEmployee();
         
        emp.getEmpId();
        emp.getEmpName();
        emp.getEmpEmail();
         li.add(emp);
        System.out.println(emp.getEmpName());
         
         
         }    
        }
      }
        
   

    
    
    
    
    
    
        }//class
   
*/

    

