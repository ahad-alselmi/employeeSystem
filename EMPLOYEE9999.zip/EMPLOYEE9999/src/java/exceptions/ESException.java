/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exceptions;

/**
 *
 * @author Lenovo
 */
public class ESException extends Exception {

    public ESException() {
        super();
    }
    
    public ESException(String data) {
        super(data);
        System.out.println(data);
    }

    public ESException(String data, Class c) {
        super(data);
        System.out.println(c.getName() + " " + data);
    }

    public ESException(Throwable cause) {
        super(cause);
    }

    public ESException(Throwable cause, Class c) {
        super(cause);
        System.out.println(c.getName() + " " + cause);
    }
    
    
}
